from flask import Flask, render_template
from Weather import get_weather_data
from Wizard import get_Wizard_Info
from Notify import send_message
import random

#Char = random.randint(1, 10)
char = random.randint(1, 40)
app = Flask('app')


@app.route('/')
def index():
  weather = get_weather_data()
  temp = round(weather["main"]["temp"] - 273.15, 2)
  desc = weather["weather"][0]["description"]
  # get_Wizard_Info(msg)
  return render_template('index.html', temp=temp, desc=desc)
  


msg = get_Wizard_Info()
#print(result[char]['wizard'])

send_message(msg)


@app.route('/success')
def success():
  # char = random.randint(1, 40)
  # msg = get_Wizard_Info()
  # #print(result[char]['wizard'])

  # send_message(msg)
  return render_template('success.html', msg=msg, char=char)
  #return render_template('success.html', char=char, result=result)


app.run(host='0.0.0.0', port=800)
