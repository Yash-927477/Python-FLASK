import urllib.request
import json
import random

def get_Wizard_Info():
  url = 'https://hp-api.onrender.com/api/characters'

  request = urllib.request.urlopen(url)
  result = json.loads(request.read())
  #print(result)

  char = random.randint(1,40)
  if result[char]['wizard'] == True:
    return f" Hey There! looks like you have a message from wizarding world. Here are some predictions about you: Your Favorite number is : {char}, You're Hogwart's identity is named as {result[char]['name']} in house {result[char]['house']} and in harry porter movie series it was played by {result[char]['actor']}, you can see his picture here: {result[char]['image']}"
  else:
    return f" Hey There! looks like you have a message from wizarding world, and sadly you are not a wizard perse. Here are some predictions about you: Your Favorite number is : {char}, You're Hogwart's identity is named as {result[char]['name']} in house {result[char]['house']} and in harry porter movie series it was played by {result[char]['actor']}, you can see his picture here: {result[char]['image']}"