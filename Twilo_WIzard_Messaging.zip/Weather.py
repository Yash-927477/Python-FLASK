import urllib.request
import json

def get_weather_data():
  key = 'de5f16c192aca2f544730a080bf248f3' #my api key
  latitude = 43.775126
  longitude = -79.345958
  # These are latitudes and longitudes of my location in toronto.
  api_url = f'https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={key}'
  response = urllib.request.urlopen(api_url)
  #print(response)
  result = json.loads(response.read())
  #print(result)

  return result