import os
from twilio.rest import Client


def send_message(msg):

  # account_SID and auth_token from my twilio.com/console
  account_sid = os.environ['TWILIO_ACCOUNT_SID']
  auth_token = os.environ['TWILIO_AUTH_TOKEN']
  client = Client(account_sid, auth_token)

  message = client.messages \
      .create(
        body = msg,
        from_= '+18476071108', #this is my twilio number
        to = '+14376679274' #this is my phone number
      )
  print(message.sid)
  return message
