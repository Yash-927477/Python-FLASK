from flask import Flask, render_template
from Iss_loc import get_Iss_loc
from Weather import get_weather_data
from Get_Address import get_address
from Country_Info import Country_Info
import urllib.request
import json
import geopy.distance

app = Flask('app')

@app.route('/')
def index():
    data = get_Iss_loc()
    latitude = data[0]
    longitude = data[1]
    weather = get_weather_data(latitude, longitude)
    temp = round(weather["main"]["temp"] - 273.15, 2)
    desc = weather["weather"][0]["description"]

    Address = get_address(latitude, longitude)
    Country_Code = Address["results"][0]["locations"][0]["adminArea1"]
    country_data = Country_Info(Country_Code)
    country_name = ""
    flag = ""
    capital = ""
    population = ""
    currencies = ""
    languages = ""
    borders = ""
  
    if Address["results"][0]["locations"][0]['adminArea1'] != "":
        location = Address["results"][0]["locations"][0]["geocodeQuality"]
        country_name = country_data["name"]
        flag = country_data["flags"]["png"]
        capital = country_data["capital"]
        population = country_data["population"]
        currencies = country_data["currencies"]
        languages = country_data["languages"]
        borders = country_data["borders"]
    
    coords_1 = (43.653225, -79.383991)  # lat & long of Toronto
    coords_2 = (latitude, longitude)  # lat & long of ISS
    distance = round(geopy.distance.distance(coords_1, coords_2).km, 2)
  
    if Address["results"][0]["locations"][0]['adminArea1'] == "":
      return render_template('index_water.html', distance=distance)
    
    return render_template('index.html', temp=temp, desc=desc, country_name=country_name, flag=flag,
                           capital=capital, population=population, currencies=currencies, languages=languages,
                           borders=borders, distance=distance)

app.run(host='0.0.0.0', port=800)
