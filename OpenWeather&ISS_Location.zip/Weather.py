import urllib.request
import json

def get_weather_data(latitude, longitude):
  key = 'de5f16c192aca2f544730a080bf248f3'
  api_url = f'https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={key}'
  response = urllib.request.urlopen(api_url)
  #print(response)
  result = json.loads(response.read())
  #print(result)
  
  return result