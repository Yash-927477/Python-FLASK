import urllib.request
import json
def get_address(latitude, longitude):
  key = 'b5lRjjHyBC9fMr1DnNUOaOK23sXANAPU'
  url = f'https://www.mapquestapi.com/geocoding/v1/reverse?key={key}&location={latitude},{longitude}&includeRoadMetadata=true&includeNearestIntersection=true'
  response = urllib.request.urlopen(url)
  print(response)
  result = json.loads(response.read())
  print(result)
  return result
