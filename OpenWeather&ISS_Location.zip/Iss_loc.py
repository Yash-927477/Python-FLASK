import urllib.request
import requests
import json
def get_Iss_loc():
  url = 'http://api.open-notify.org/iss-now.json'
  response = urllib.request.urlopen(url)
  result = json.loads(response.read())
  # print(result)
  
  latitude = result['iss_position']['latitude']
  longitude = result['iss_position']['longitude']
  print(latitude, longitude)
  
  print("https://www.google.ca/maps/place/"+latitude +"+"+longitude)
  return latitude, longitude