import urllib.request
import json

def Country_Info(Country_Code):
  co = Country_Code
  url = f'https://restcountries.com/v3.1/alpha/{co}'
  response = urllib.request.urlopen(url)
  result = json.loads(response.read())
  #print(result)
  return result